package org.opencds.cqf.cql.evaluator.dagger.measure;

import org.opencds.cqf.cql.evaluator.dagger.builder.BuilderModule;

import dagger.Module;

@Module(includes = {BuilderModule.class})
public class MeasureModule {

}