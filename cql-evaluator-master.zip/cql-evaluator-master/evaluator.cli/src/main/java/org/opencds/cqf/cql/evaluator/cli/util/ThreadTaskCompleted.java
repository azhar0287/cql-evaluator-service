package org.opencds.cqf.cql.evaluator.cli.util;

public class ThreadTaskCompleted {
    public boolean isTaskCompleted = false;
}
